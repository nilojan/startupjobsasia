define('ace/snippets/velocity', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "velocity";

});
