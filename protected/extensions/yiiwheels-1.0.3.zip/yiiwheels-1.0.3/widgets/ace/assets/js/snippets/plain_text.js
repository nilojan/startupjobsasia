define('ace/snippets/plain_text', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "plain_text";

});
