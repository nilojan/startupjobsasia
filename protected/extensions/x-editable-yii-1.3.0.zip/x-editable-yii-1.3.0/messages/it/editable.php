<?php
/**
 * Italian translation for X-editable.
 * 
 * @author Manuel (https://github.com/manuel-84)
*/

return array (
     'Enter' => 'Inserisci',
     'Select' => 'Seleziona',
);
