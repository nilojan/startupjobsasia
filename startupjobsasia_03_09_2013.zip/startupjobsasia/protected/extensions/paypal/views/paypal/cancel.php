<?php
$this->breadcrumbs=array(
	'Paypal'=>array('/paypal'),
	'Cancel',
);
?>

<div>
	<h3>Payment Cancellation</h3>
	<p>
		The payment was cancelled by the user.
	</p>
</div>