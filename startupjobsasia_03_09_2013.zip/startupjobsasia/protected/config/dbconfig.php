<?php

define("global_dbhost", "localhost");
define("global_emulatePrepare", "true");
define("global_dbusername", "root");
define("global_dbpassword", "");
define("global_dbdatabase", "mydb");
define("global_charset", "utf8");

?>